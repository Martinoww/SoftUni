import { createComment, deleteGame, getAllCommentsForASpecificGame, getGameById } from "../api/data.js";
import { getUserData } from "../api/util.js";
import { html } from "../lib.js";

const detailsTemplate = (game, isOwner, onDelete, isUser, comments, onComment) => html`
<section id="game-details">
  <h1>Game Details</h1>
  <div class="info-section">
    <div class="game-header">
      <img class="game-img" src=${game.imageUrl} />
      <h1>${game.title}</h1>
      <span class="levels">MaxLevel: ${game.maxLevel}</span>
      <p class="type">${game.category}</p>
    </div>
    <p class="text">${game.summary}</p>
    <div class="details-comments">
      <h2>Comments:</h2>
      ${comments.length != 0 
        ? html`<ul>${comments.map(commentTemplate)}</ul>` 
        : html`<p class="no-comment">No comments.</p>`}
    </div>
    ${isOwner
      ? html`<div class="buttons">
          <a href="/edit/${game._id}" class="button">Edit</a>
          <a @click=${onDelete} href="javascript:void(0)" class="button"
            >Delete</a
          >
        </div>`
      : null}
  </div>
    ${isUser 
      ? html`<article class="create-comment">
             <label>Add new comment:</label>
             <form @submit=${onComment} class="form">
             <textarea name="comment" placeholder="Comment......"></textarea>
             <input class="btn submit" type="submit" value="Add Comment" />
             </form>
            </article>` 
      : null}
</section>`;


const commentTemplate = (comment) => html`
<li class="comment">
  <p>Content: ${comment.comment}</p>
</li>`;

export async function detailsPage(ctx) {
  const game = await getGameById(ctx.params.id);
  let comments = await getAllCommentsForASpecificGame(ctx.params.id);
  const userData = getUserData();
  const isOwner = userData && userData.id == game._ownerId;
  const isUser = userData && userData.id != game._ownerId;
  update(game, isOwner, isUser, comments);
  function update(game = [], isOwner = false, isUser = false, comments = []){
    ctx.render(detailsTemplate(game, isOwner, onDelete, isUser, comments, onComment));
  }

  async function onDelete() {
    const confirmation = confirm(
      `Are you sure you want to delete ${game.title}`
    );
    if (confirmation) {
      await deleteGame(ctx.params.id);
      ctx.page.redirect("/");
    }
  }

async function onComment(event){
  event.preventDefault();
  const formData = new FormData(event.target);
  const commentContent = formData.get('comment').trim();
  if(commentContent == ''){
    alert('All fields are required!');
  }else {
    const data = {'gameId': ctx.params.id, 'comment': commentContent}
    await createComment(data);
    event.target.reset();
   comments = await getAllCommentsForASpecificGame(ctx.params.id);
    update(game, isOwner, isUser, comments);


  }
}

}
