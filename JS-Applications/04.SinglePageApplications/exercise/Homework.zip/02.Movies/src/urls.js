export const allUrls = {
    'getAllMovies': 'http://localhost:3030/data/movies',
    'createMoviePOSTreq': 'http://localhost:3030/data/movies',
    'updateMoviePUTreq': 'http://localhost:3030/data/movies/',
    'deleteMovie':'http://localhost:3030/data/movies/',
    'addLikePOSTreq': 'http://localhost:3030/data/likes',
    'removeLikeDELETEreq': 'http://localhost:3030/data/likes/'
}