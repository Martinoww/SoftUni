const main = document.querySelector('main');


export function showView(section){

main.replaceChildren(section);

}
